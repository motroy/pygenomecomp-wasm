import subprocess
import sys
import tempfile
#import shutil
import os
import pathlib

REFERENCE_FASTA = """>ref_contig_1
AGCTTTTCATTCTGACTGCAACGGGCAATATGTCTCTGTGTGGATTAAAAAAAGAGTGTCTGATAGCAGCTTCTGAACTGGTTACCTGCCGTGAGTAAATTAAAATTTTATTGACTTAGGTCACTAAATACTTTAACCAATATAGGCATAGCGCACAGACAGATAAAAATTACAGAGTACACAACATCCATGAAAC
"""
QUERY1_FASTA = """>query_A
AGCTTTTCATTCTGACTGCAACGGGCAATATGTCTCTGTGTGGATTAAAAAAAGAGTGTCTGATAGCAGCTTCTGAACTGGTTACCTGCCGTGAGTAAATTAAAATTTTATTGACTTAGGTCACTAAATACTTTAACCAATATAGGCATAGCGCACAGACAGATAAAAATTACAGAGTACACAACATCCATGAAAC
"""
QUERY2_FASTA = """>query_B_reversed
CCTGTACACCAGCACGGTTTGTTTGGGCAAATTCCTGATCGACGAAAGTTTTCAATTGCGCCAGCGGGAACCCCGGCTGGGCGGCGGCGAGTCCCGTCAAAAGTTCGGCAAAAATACGTTCGGCATCGCTGATATTGGGTAAAGCATCCTGGCCGCTAATGGTTTTTTCAATCATCGCCACCAGGTGGTTGGTGAT
"""
# Query with a 50 bp insertion in the middle, making it 250 bp (larger than the 196 bp reference).
# Left flank: first 100 bp of reference (positions 1-100).
# Insertion: 50 T's not present in the reference.
# Right flank: last 100 bp of reference (positions 97-196), so both segments are >= min_length.
QUERY_WITH_INSERTION_FASTA = """>query_with_insertion
AGCTTTTCATTCTGACTGCAACGGGCAATATGTCTCTGTGTGGATTAAAAAAAGAGTGTCTGATAGCAGCTTCTGAACTGGTTACCTGCCGTGAGTAAATTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTAAATTAAAATTTTATTGACTTAGGTCACTAAATACTTTAACCAATATAGGCATAGCGCACAGACAGATAAAAATTACAGAGTACACAACATCCATGAAAC
"""
ANNOTATIONS_GFF3 = """##gff-version 3
ref_contig_1	Prokka	gene	350	450	.	+	.	ID=gene01;Name=ABC_transporter
ref_contig_1	Prokka	CDS	350	450	.	+	0	ID=cds01;Parent=gene01;product=ATP-binding cassette transporter
ref_contig_1	Prokka	rRNA	120	220	.	-	.	ID=rrna01;product=16S ribosomal RNA
"""

def write_file(path, content):
    with open(path, "w") as f:
        f.write(content)

def test_find_insertion_sites_detects_query_insertion():
    """
    Unit test for blast.find_insertion_sites().

    A query with a 5,000 bp insertion at reference position 200,000 produces
    two BLAST hits whose reference coordinates are contiguous but whose query
    coordinates have a 5,000 bp gap.  find_insertion_sites() must detect
    exactly one insertion site of the correct size.
    """
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))
    from pygenomecomp.blast import find_insertion_sites

    hits = [
        {'qseqid': 'q', 'sseqid': 's', 'pident': 99.9, 'length': 200000,
         'qstart': 1, 'qend': 200000, 'sstart': 1, 'send': 200000,
         'query_index': 0},
        {'qseqid': 'q', 'sseqid': 's', 'pident': 99.9, 'length': 465000,
         'qstart': 205001, 'qend': 670000, 'sstart': 200001, 'send': 665000,
         'query_index': 0},
    ]
    sites = find_insertion_sites(hits)
    assert len(sites) == 1, f"Expected 1 insertion site, got {len(sites)}"
    assert sites[0]['insertion_size'] == 5000
    assert abs(sites[0]['ref_position'] - 200000.5) < 0.1
    assert sites[0]['query_index'] == 0


def test_find_insertion_sites_ignores_cross_contig_gaps():
    """
    Regression test: when the reference has multiple contigs (different sseqid),
    a gap in query coordinates between hits on different reference contigs must
    NOT be reported as an insertion.

    This replicates the vim-plasmids bug where a query maps to two reference
    contigs (AAXVQW010000045.1 at positions 1-2934 and AAXVQW010000026.1 at
    positions 288-1140).  The apparent "gap" of 13,084 bp in query coordinates
    is a cross-contig artefact, not a real insertion.
    """
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))
    from pygenomecomp.blast import find_insertion_sites

    hits = [
        # Hit on reference contig 2 – covers the whole contig
        {'qseqid': 'CP031570.1', 'sseqid': 'gb|AAXVQW010000045.1|',
         'pident': 100.0, 'length': 2934,
         'qstart': 109220, 'qend': 112153, 'sstart': 1, 'send': 2934,
         'query_index': 0},
        # Hit on reference contig 1 – partial match at different query region
        {'qseqid': 'CP031570.1', 'sseqid': 'gb|AAXVQW010000026.1|',
         'pident': 89.4, 'length': 853,
         'qstart': 125238, 'qend': 126090, 'sstart': 288, 'send': 1140,
         'query_index': 0},
    ]
    sites = find_insertion_sites(hits)
    assert len(sites) == 0, (
        f"Cross-contig query gaps must not be reported as insertions, got: {sites}"
    )


def test_find_insertion_sites_ignores_reference_deletions():
    """
    Unit test: a deletion in the query (large reference gap between hits, as
    seen in the sim90 test data) must NOT be reported as an insertion.
    """
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))
    from pygenomecomp.blast import find_insertion_sites

    # Simulates sim90: reference gap of ~22 kb, no query gap
    hits = [
        {'qseqid': 'q', 'sseqid': 's', 'pident': 98.0, 'length': 100000,
         'qstart': 1, 'qend': 100000, 'sstart': 1, 'send': 100006,
         'query_index': 0},
        {'qseqid': 'q', 'sseqid': 's', 'pident': 98.0, 'length': 177833,
         'qstart': 100001, 'qend': 277833, 'sstart': 122182, 'send': 300008,
         'query_index': 0},
    ]
    sites = find_insertion_sites(hits)
    assert len(sites) == 0, (
        f"Deletion regions must not be reported as insertions, got: {sites}"
    )


def test_generate_plot_renders_insertion_marker():
    """
    Unit test: generate_plot() must include a visible insertion marker
    (#1a1a1a arc + size label + legend entry) when insertion_sites are provided.
    """
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))
    from pygenomecomp.plot import generate_plot

    hits = [
        {'qseqid': 'q', 'sseqid': 's', 'pident': 99.9, 'length': 200000,
         'qstart': 1, 'qend': 200000, 'sstart': 1, 'send': 200000,
         'query_index': 0},
        {'qseqid': 'q', 'sseqid': 's', 'pident': 99.9, 'length': 465000,
         'qstart': 205001, 'qend': 670000, 'sstart': 200001, 'send': 665000,
         'query_index': 0},
    ]
    insertion_sites = [
        {'ref_position': 200000.5, 'insertion_size': 5000, 'query_index': 0}
    ]

    with tempfile.TemporaryDirectory() as tmpdir:
        out = pathlib.Path(tmpdir) / "insertion_test.svg"
        generate_plot(
            blast_hits=hits,
            annotations=None,
            reference_length=665000,
            query_names=["test_query.fasta"],
            output_path=out,
            reference_display_name="test_ref",
            insertion_sites=insertion_sites,
        )
        svg = out.read_text()
        assert "<svg" in svg, "SVG output does not contain <svg> tag"
        assert "#1a1a1a" in svg, (
            "SVG does not contain insertion marker color (#1a1a1a). "
            "Insertion regions are not being visualised."
        )
        assert "+5.0 kb" in svg, "SVG does not contain insertion size label"
        assert "Insertion site" in svg, "SVG legend does not list insertion sites"


def test_minimal_working_example():
    with tempfile.TemporaryDirectory() as tmpdir:
        ref = os.path.join(tmpdir, "reference.fasta")
        q1 = os.path.join(tmpdir, "query1.fasta")
        q2 = os.path.join(tmpdir, "query2.fasta")
        ann = os.path.join(tmpdir, "annotations.gff3")
        outdir = os.path.join(tmpdir, "my_comparison_results")

        write_file(ref, REFERENCE_FASTA)
        write_file(q1, QUERY1_FASTA)
        write_file(q2, QUERY2_FASTA)
        write_file(ann, ANNOTATIONS_GFF3)

        # Run the CLI
        env = os.environ.copy()
        env["PYTHONPATH"] = os.path.abspath("src")
        result = subprocess.run([
            sys.executable, "-m", "pygenomecomp.main",
            "--reference", ref,
            "--queries", q1, q2,
            "--annotations", ann,
            "--output_dir", outdir
        ], capture_output=True, text=True, env=env)

        # For debugging on CI
        print("STDOUT:", result.stdout)
        print("STDERR:", result.stderr)

        assert result.returncode == 0, f"pygenomecomp failed: {result.stderr}"

        # Check output directory and expected SVG
        plot_path = os.path.join(outdir, "comparison_plot.svg")
        assert os.path.isdir(outdir), "Output directory was not created"
        assert os.path.isfile(plot_path), "SVG plot was not generated"

        # Optionally, check that the SVG file is not empty/minimal
        with open(plot_path) as f:
            svg = f.read()
            assert "<svg" in svg, "SVG output does not contain <svg> tag"

def test_query_larger_than_reference_due_to_insertion():
    """
    Regression test: a query genome that is larger than the reference due to an
    insertion should be handled without errors and produce a valid SVG plot.

    The query (250 bp) contains:
      - Left flank: first 100 bp identical to the reference (positions 1-100)
      - A 50 bp insertion of T's not present in the reference
      - Right flank: last 100 bp of the reference (positions 97-196)

    BLAST will report two separate hits (one per flank), each 100 bp long,
    both satisfying the default min_length=100 filter.
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        ref = os.path.join(tmpdir, "reference.fasta")
        q_ins = os.path.join(tmpdir, "query_insertion.fasta")
        outdir = os.path.join(tmpdir, "insertion_results")

        write_file(ref, REFERENCE_FASTA)
        write_file(q_ins, QUERY_WITH_INSERTION_FASTA)

        env = os.environ.copy()
        env["PYTHONPATH"] = os.path.abspath("src")
        result = subprocess.run([
            sys.executable, "-m", "pygenomecomp.main",
            "--reference", ref,
            "--queries", q_ins,
            "--output_dir", outdir,
        ], capture_output=True, text=True, env=env)

        print("STDOUT:", result.stdout)
        print("STDERR:", result.stderr)

        assert result.returncode == 0, f"pygenomecomp failed for insertion query: {result.stderr}"

        plot_path = os.path.join(outdir, "comparison_plot.svg")
        assert os.path.isdir(outdir), "Output directory was not created"
        assert os.path.isfile(plot_path), "SVG plot was not generated"

        with open(plot_path) as f:
            svg = f.read()
            assert "<svg" in svg, "SVG output does not contain <svg> tag"
            # The insertion site marker should be drawn as a near-black arc (#1a1a1a)
            assert "#1a1a1a" in svg, (
                "SVG does not contain an insertion site marker (#1a1a1a arc). "
                "The insertion region in the query is not being visualised."
            )


def test_mhominis_query_with_insertion_larger_than_reference():
    """
    Integration test using the real M. hominis PG21 reference genome.

    A simulated query is built by inserting a 5,000 bp synthetic high-GC
    sequence (GCGC repeat) into the PG21 genome at position 200,000.
    The resulting query (670,000 bp) is larger than the reference (665,000 bp).
    The tool should produce a valid SVG plot without errors, with BLAST
    finding two large flanking hits (left: 200,000 bp, right: 465,000 bp)
    that both pass all default filters.
    """
    from Bio import SeqIO
    from Bio.SeqRecord import SeqRecord
    from Bio.Seq import Seq

    data_dir = os.path.join(os.path.dirname(__file__), "data", "mhominis")
    reference_fasta = os.path.join(data_dir, "mhominis_PG21.fasta")

    ref_record = next(SeqIO.parse(reference_fasta, "fasta"))
    ref_seq = str(ref_record.seq)
    ref_length = len(ref_seq)

    # Insert 5,000 bp of high-GC synthetic sequence at position 200,000.
    # PG21 is AT-rich (27% GC), so this insertion is clearly non-native and
    # will not produce false BLAST hits against the reference.
    insertion_pos = 200_000
    insertion_seq = "GCGC" * 1_250  # 5,000 bp
    query_seq = ref_seq[:insertion_pos] + insertion_seq + ref_seq[insertion_pos:]

    assert len(query_seq) == ref_length + 5_000

    with tempfile.TemporaryDirectory() as tmpdir:
        query_record = SeqRecord(Seq(query_seq), id="mhominis_sim_insertion", description="")
        query_fasta = os.path.join(tmpdir, "mhominis_sim_insertion.fasta")
        SeqIO.write(query_record, query_fasta, "fasta")

        outdir = os.path.join(tmpdir, "mhominis_insertion_results")

        env = os.environ.copy()
        env["PYTHONPATH"] = os.path.abspath("src")
        result = subprocess.run([
            sys.executable, "-m", "pygenomecomp.main",
            "--reference", reference_fasta,
            "--queries", query_fasta,
            "--output_dir", outdir,
        ], capture_output=True, text=True, env=env)

        print("STDOUT:", result.stdout)
        print("STDERR:", result.stderr)

        assert result.returncode == 0, (
            f"pygenomecomp failed for mhominis insertion query: {result.stderr}"
        )

        plot_path = os.path.join(outdir, "comparison_plot.svg")
        assert os.path.isdir(outdir), "Output directory was not created"
        assert os.path.isfile(plot_path), "SVG plot was not generated"

        with open(plot_path) as f:
            svg = f.read()
            assert "<svg" in svg, "SVG output does not contain <svg> tag"
            # The insertion site marker should be drawn as a near-black arc (#1a1a1a)
            assert "#1a1a1a" in svg, (
                "SVG does not contain an insertion site marker (#1a1a1a arc). "
                "The insertion region in the query is not being visualised."
            )


# If you want to run with pytest, add this at the end:
if __name__ == "__main__":
    import pytest
    pytest.main([__file__])