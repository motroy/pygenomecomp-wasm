from __future__ import annotations

import subprocess
import shutil
import pandas as pd
from pathlib import Path

def _run_command(cmd):
    """Run an external command and handle errors."""
    if not shutil.which(cmd[0]):
        raise FileNotFoundError(
            f"Command '{cmd[0]}' not found. Please ensure BLAST+ is installed and in your PATH."
        )
    process = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if process.returncode != 0:
        raise RuntimeError(
            f"Command failed with exit code {process.returncode}:\n"
            f"Command: {' '.join(map(str, cmd))}\n"
            f"Stderr: {process.stderr}"
        )
    return process

def make_blast_db(reference_fasta: Path, db_prefix: Path):
    """Creates a BLAST database from a reference FASTA file."""
    cmd = [
        "makeblastdb",
        "-in", str(reference_fasta),
        "-dbtype", "nucl",
        "-out", str(db_prefix),
        "-parse_seqids"
    ]
    _run_command(cmd)

def run_blastn(query_fasta: Path, db_prefix: Path, output_file: Path, evalue: float, min_identity: float):
    """Runs blastn and saves the output in tabular format."""
    outfmt = "6 qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore qlen slen"
    cmd = [
        "blastn",
        "-query", str(query_fasta),
        "-db", str(db_prefix),
        "-out", str(output_file),
        "-outfmt", outfmt,
        "-evalue", str(evalue),
        "-perc_identity", str(min_identity)
    ]
    _run_command(cmd)

def parse_blast_output(blast_output_file: Path, min_identity: float, min_length: int) -> list[dict]:
    """Parses BLAST tabular output into a list of dictionaries using pandas."""
    col_names = [
        "qseqid", "sseqid", "pident", "length", "mismatch", "gapopen",
        "qstart", "qend", "sstart", "send", "evalue", "bitscore", "qlen", "slen"
    ]
    try:
        df = pd.read_csv(blast_output_file, sep='\t', header=None, names=col_names)

        # Filter based on identity and length
        filtered_df = df[(df['pident'] >= min_identity) & (df['length'] >= min_length)]

        # Convert to a list of dictionaries for easier processing
        return filtered_df.to_dict('records')
    except pd.errors.EmptyDataError:
        return [] # Return empty list if blast output is empty
    except Exception as e:
        raise RuntimeError(f"Failed to parse BLAST output file {blast_output_file}: {e}")


def find_insertion_sites(hits: list[dict], max_ref_gap: int = 50) -> list[dict]:
    """
    Identifies insertion sites in a query relative to the reference.

    An insertion is detected when two consecutive BLAST hits (sorted by
    reference position) have a small or zero gap in reference coordinates
    (≤ max_ref_gap) but a gap in query coordinates, indicating unaligned
    query sequence not present in the reference.

    Args:
        hits: List of BLAST hit dicts for a single query (all sharing the same
              query_index, already set by the caller).
        max_ref_gap: Maximum reference gap (bp) between consecutive hits to
                     still classify the event as a query insertion rather than
                     a reference deletion. Default: 50.

    Returns:
        List of dicts with keys:
            'ref_position'   – fractional reference bp at the insertion junction
            'insertion_size' – number of inserted query bp not in the reference
            'query_index'    – same query_index as the input hits
    """
    if len(hits) < 2:
        return []

    # Sort hits by reference start position (handle reverse-complement hits)
    sorted_hits = sorted(hits, key=lambda h: min(h['sstart'], h['send']))

    insertion_sites = []
    for i in range(len(sorted_hits) - 1):
        h1 = sorted_hits[i]
        h2 = sorted_hits[i + 1]

        # Reference coordinates (normalise for reverse-complement hits)
        ref_end = max(h1['sstart'], h1['send'])
        ref_start_next = min(h2['sstart'], h2['send'])
        ref_gap = ref_start_next - ref_end - 1  # negative → hits overlap in ref

        # Query coordinates (normalise for reverse-complement hits)
        q_end = max(h1['qstart'], h1['qend'])
        q_start_next = min(h2['qstart'], h2['qend'])
        query_gap = q_start_next - q_end - 1  # negative → hits overlap in query

        # An insertion: the reference is (nearly) continuous but the query has
        # unaligned sequence between the two hits.  Both hits must be on the
        # same reference contig (sseqid); cross-contig comparisons are not
        # meaningful because reference coordinates are independent per contig.
        if ref_gap <= max_ref_gap and query_gap > 0 and h1['sseqid'] == h2['sseqid']:
            insertion_sites.append({
                'ref_position': ref_end + 0.5,  # junction point in reference coords
                'insertion_size': query_gap,
                'query_index': h1['query_index'],
            })

    return insertion_sites
