import math
import svgwrite
from pathlib import Path
from typing import List, Optional, Dict
from .annotation import AnnotationFeature

# --- Constants for BRIG-style visual layout ---
SVG_WIDTH, SVG_HEIGHT = 1200, 1000
CENTER_X, CENTER_Y = 500, 500

# Ring layout (from center outward)
ANNOTATION_RING_RADIUS_INNER = 140.0
ANNOTATION_RING_THICKNESS = 20.0
ANNOTATION_RING_RADIUS_OUTER = ANNOTATION_RING_RADIUS_INNER + ANNOTATION_RING_THICKNESS

REFERENCE_RING_RADIUS = ANNOTATION_RING_RADIUS_OUTER + 4.0

BLAST_HIT_BASE_RADIUS = REFERENCE_RING_RADIUS + 4.0
BLAST_RING_THICKNESS = 28.0
BLAST_RING_SPACING = 2.0

# BRIG-style color palette (RGB tuples) for query rings
RING_COLORS = [
    (227, 26, 28),    # Red
    (55, 126, 184),   # Blue
    (77, 175, 74),    # Green
    (152, 78, 163),   # Purple
    (255, 127, 0),    # Orange
    (166, 86, 40),    # Brown
    (247, 129, 191),  # Pink
    (153, 153, 153),  # Grey
]

# Annotation feature colors
ANNOTATION_COLORS = {
    "cds": "#4682B4",
    "gene": "#3CB371",
    "trna": "#FF6347",
    "rrna": "#EE82EE",
}
DEFAULT_ANNOTATION_COLOR = "#808080"


def _rgb_to_hex(r, g, b):
    """Convert RGB integers (0-255) to hex color string."""
    return f'#{r:02x}{g:02x}{b:02x}'


def _get_ring_color(query_index):
    """Get the base RGB color tuple for a query ring."""
    return RING_COLORS[query_index % len(RING_COLORS)]


def _get_blast_hit_color(query_index, identity):
    """
    Returns a hex color for a BLAST hit segment.
    Higher identity = full saturated color; lower identity = lighter tint.
    """
    base_r, base_g, base_b = _get_ring_color(query_index)

    min_identity = 70.0
    max_identity = 100.0
    identity = max(min_identity, min(max_identity, identity))

    # fraction: 0 at 70% identity → 1 at 100% identity
    frac = (identity - min_identity) / (max_identity - min_identity)

    # Blend from light tint toward full color
    # At 70%: 40% base + 60% white; at 100%: 100% base
    strength = 0.4 + 0.6 * frac
    r = int(255 - (255 - base_r) * strength)
    g = int(255 - (255 - base_g) * strength)
    b = int(255 - (255 - base_b) * strength)

    return _rgb_to_hex(r, g, b)


def _get_ring_background_color(query_index):
    """Returns a very light tint of the ring color for the background band."""
    base_r, base_g, base_b = _get_ring_color(query_index)
    factor = 0.10
    r = int(255 - (255 - base_r) * factor)
    g = int(255 - (255 - base_g) * factor)
    b = int(255 - (255 - base_b) * factor)
    return _rgb_to_hex(r, g, b)


def get_annotation_feature_color(feature_type: str) -> str:
    """Maps annotation feature type to a specific color."""
    return ANNOTATION_COLORS.get(feature_type.lower(), DEFAULT_ANNOTATION_COLOR)


def _draw_arc_segment(dwg, center_x, center_y, r_inner, r_outer,
                      start_rad, end_rad, color, opacity=1.0,
                      stroke='none', stroke_width=0):
    """Draws a filled arc segment (annular sector)."""
    large_arc_flag = 1 if abs(end_rad - start_rad) > math.pi else 0

    x_start_outer = center_x + r_outer * math.cos(start_rad)
    y_start_outer = center_y + r_outer * math.sin(start_rad)
    x_end_outer = center_x + r_outer * math.cos(end_rad)
    y_end_outer = center_y + r_outer * math.sin(end_rad)

    x_start_inner = center_x + r_inner * math.cos(start_rad)
    y_start_inner = center_y + r_inner * math.sin(start_rad)
    x_end_inner = center_x + r_inner * math.cos(end_rad)
    y_end_inner = center_y + r_inner * math.sin(end_rad)

    path_data = (
        f"M {x_start_outer} {y_start_outer} "
        f"A {r_outer} {r_outer} 0 {large_arc_flag} 1 {x_end_outer} {y_end_outer} "
        f"L {x_end_inner} {y_end_inner} "
        f"A {r_inner} {r_inner} 0 {large_arc_flag} 0 {x_start_inner} {y_start_inner} Z"
    )
    dwg.add(dwg.path(
        d=path_data, fill=color, stroke=stroke,
        stroke_width=stroke_width, opacity=opacity,
    ))


def _draw_full_ring(dwg, center_x, center_y, r_inner, r_outer,
                    color, opacity=1.0):
    """Draws a complete circle ring (annulus) as two semicircular arcs."""
    _draw_arc_segment(dwg, center_x, center_y, r_inner, r_outer,
                      -math.pi / 2, math.pi / 2, color, opacity)
    _draw_arc_segment(dwg, center_x, center_y, r_inner, r_outer,
                      math.pi / 2, 3 * math.pi / 2, color, opacity)


def generate_plot(blast_hits: List[Dict],
                  annotations: Optional[List[AnnotationFeature]],
                  reference_length: int,
                  query_names: List[str],
                  output_path: Path,
                  reference_display_name: str,
                  show_gene_names: bool = False,
                  insertion_sites: Optional[List[Dict]] = None):
    """
    Generates a BRIG-style circular SVG plot.

    Args:
        blast_hits: List of BLAST hit dictionaries.
        annotations: List of AnnotationFeature objects.
        reference_length: The total length of the reference sequence.
        query_names: A list of query filenames for the legend.
        output_path: The path to save the output SVG file.
        reference_display_name: The name of the reference sequence for display.
        show_gene_names: Whether to draw gene name labels on the annotation ring.
        insertion_sites: Optional list of insertion site dicts, each with keys
            'ref_position', 'insertion_size', and 'query_index'.  Each site is
            rendered as a thin dark arc on the corresponding query ring plus a
            tick mark and size label outside the rings.
    """
    if reference_length == 0:
        raise ValueError("Reference length cannot be zero.")

    n_queries = len(query_names)

    # Compute the outermost blast ring radius
    if n_queries > 0:
        outermost_blast_r = (
            BLAST_HIT_BASE_RADIUS
            + n_queries * BLAST_RING_THICKNESS
            + (n_queries - 1) * BLAST_RING_SPACING
        )
    else:
        outermost_blast_r = REFERENCE_RING_RADIUS + 10

    tick_radius_inner = outermost_blast_r + 6
    tick_radius_outer = tick_radius_inner + 10
    label_radius = tick_radius_outer + 18

    dwg = svgwrite.Drawing(
        str(output_path),
        size=(f"{SVG_WIDTH}px", f"{SVG_HEIGHT}px"),
        profile='full',
    )
    dwg.add(dwg.style("text { font-family: Arial, Helvetica, sans-serif; }"))

    # --- White background ---
    dwg.add(dwg.rect(
        insert=(0, 0), size=(SVG_WIDTH, SVG_HEIGHT), fill='white',
    ))

    # --- White center fill ---
    dwg.add(dwg.circle(
        center=(CENTER_X, CENTER_Y),
        r=ANNOTATION_RING_RADIUS_INNER - 2,
        fill='white', stroke='none',
    ))

    # --- Center text ---
    dwg.add(dwg.text(
        reference_display_name,
        insert=(CENTER_X, CENTER_Y - 10),
        text_anchor='middle', alignment_baseline='middle',
        font_size='14px', font_weight='bold', fill='#333',
    ))
    dwg.add(dwg.text(
        f"{reference_length:,} bp",
        insert=(CENTER_X, CENTER_Y + 12),
        text_anchor='middle', alignment_baseline='middle',
        font_size='12px', fill='#666',
    ))

    # --- Annotation Ring (inner ring) ---
    if annotations:
        _draw_full_ring(
            dwg, CENTER_X, CENTER_Y,
            ANNOTATION_RING_RADIUS_INNER, ANNOTATION_RING_RADIUS_OUTER,
            '#f0f0f0',
        )

        for feature in annotations:
            map_start = feature.start - 1
            map_end = feature.end
            start_rad = (map_start / reference_length) * 2 * math.pi - math.pi / 2
            end_rad = (map_end / reference_length) * 2 * math.pi - math.pi / 2
            if abs(end_rad - start_rad) < 1e-6:
                continue
            color = get_annotation_feature_color(feature.feature_type)
            _draw_arc_segment(
                dwg, CENTER_X, CENTER_Y,
                ANNOTATION_RING_RADIUS_INNER, ANNOTATION_RING_RADIUS_OUTER,
                start_rad, end_rad, color, opacity=0.9,
            )

            if show_gene_names and feature.feature_type.lower() == "gene":
                mid_rad = (start_rad + end_rad) / 2
                gene_name = (
                    feature.attributes.get("Name")
                    or feature.id
                    or feature.attributes.get("gene")
                    or ""
                )
                if gene_name:
                    # Leader line: from annotation ring outer edge to just before label
                    leader_end_r = outermost_blast_r + 40
                    x1 = CENTER_X + (ANNOTATION_RING_RADIUS_OUTER + 2) * math.cos(mid_rad)
                    y1 = CENTER_Y + (ANNOTATION_RING_RADIUS_OUTER + 2) * math.sin(mid_rad)
                    x2 = CENTER_X + (leader_end_r - 4) * math.cos(mid_rad)
                    y2 = CENTER_Y + (leader_end_r - 4) * math.sin(mid_rad)
                    dwg.add(dwg.line(
                        start=(x1, y1), end=(x2, y2),
                        stroke='#aaa', stroke_width=0.7,
                    ))
                    # Label outside all rings, radially rotated
                    label_r = outermost_blast_r + 45
                    x = CENTER_X + label_r * math.cos(mid_rad)
                    y = CENTER_Y + label_r * math.sin(mid_rad)
                    deg = math.degrees(mid_rad)
                    # Flip left-half labels to avoid upside-down text
                    rot = deg + 90 if -90 <= deg <= 90 else deg - 90
                    dwg.add(dwg.text(
                        gene_name, insert=(x, y),
                        font_size="9px", text_anchor="middle",
                        alignment_baseline="middle",
                        fill="#222", stroke="white", stroke_width=2,
                        style="pointer-events:none; paint-order: stroke fill",
                        transform=f"rotate({rot:.1f},{x:.3f},{y:.3f})",
                    ))

    # --- Reference backbone ring (thin dark circle) ---
    dwg.add(dwg.circle(
        center=(CENTER_X, CENTER_Y), r=REFERENCE_RING_RADIUS,
        fill='none', stroke='#333333', stroke_width=2.0,
    ))

    # --- BLAST Hit Rings: backgrounds first, then hits ---
    # Draw background bands for all query rings
    for i in range(n_queries):
        inner_r = BLAST_HIT_BASE_RADIUS + i * (BLAST_RING_THICKNESS + BLAST_RING_SPACING)
        outer_r = inner_r + BLAST_RING_THICKNESS
        bg_color = _get_ring_background_color(i)
        _draw_full_ring(dwg, CENTER_X, CENTER_Y, inner_r, outer_r, bg_color)
        # Subtle border circles for each ring
        dwg.add(dwg.circle(
            center=(CENTER_X, CENTER_Y), r=inner_r,
            fill='none', stroke='#ddd', stroke_width=0.5,
        ))
        dwg.add(dwg.circle(
            center=(CENTER_X, CENTER_Y), r=outer_r,
            fill='none', stroke='#ddd', stroke_width=0.5,
        ))

    # Draw BLAST hit segments on top of backgrounds
    for hit in blast_hits:
        qi = hit['query_index']
        inner_r = BLAST_HIT_BASE_RADIUS + qi * (BLAST_RING_THICKNESS + BLAST_RING_SPACING)
        outer_r = inner_r + BLAST_RING_THICKNESS

        s_start = min(hit['sstart'], hit['send'])
        s_end = max(hit['sstart'], hit['send'])
        start_rad = ((s_start - 1) / reference_length) * 2 * math.pi - math.pi / 2
        end_rad = ((s_end - 1) / reference_length) * 2 * math.pi - math.pi / 2
        if abs(end_rad - start_rad) < 1e-6:
            continue

        color = _get_blast_hit_color(qi, hit['pident'])
        _draw_arc_segment(
            dwg, CENTER_X, CENTER_Y, inner_r, outer_r,
            start_rad, end_rad, color, opacity=1.0,
        )

    # --- Insertion Site Markers ---
    # Each insertion is drawn as a thin dark arc on the relevant query ring,
    # plus an outward tick and a size label.  A minimum angular half-width is
    # enforced so the marker is always visible regardless of genome size.
    INSERTION_COLOR = '#1a1a1a'          # near-black marker
    INSERTION_MIN_HALF_WIDTH = 0.012     # radians (~0.7°) minimum arc half-width

    if insertion_sites:
        for site in insertion_sites:
            qi = site['query_index']
            inner_r = BLAST_HIT_BASE_RADIUS + qi * (BLAST_RING_THICKNESS + BLAST_RING_SPACING)
            outer_r = inner_r + BLAST_RING_THICKNESS

            ref_pos = site['ref_position']
            mid_rad = (ref_pos / reference_length) * 2 * math.pi - math.pi / 2

            # Angular half-width: at least INSERTION_MIN_HALF_WIDTH, or 1 bp worth
            one_bp_rad = (1.0 / reference_length) * 2 * math.pi
            half_width = max(INSERTION_MIN_HALF_WIDTH, one_bp_rad)

            start_rad = mid_rad - half_width
            end_rad = mid_rad + half_width

            # Thin dark arc on the query ring
            _draw_arc_segment(
                dwg, CENTER_X, CENTER_Y, inner_r, outer_r,
                start_rad, end_rad, INSERTION_COLOR, opacity=0.85,
            )

            # Outward tick mark just outside ALL rings (not just the query ring),
            # using the same radii as the scale tick marks so the labels sit in
            # the same readable band around the circumference.
            x1 = CENTER_X + tick_radius_inner * math.cos(mid_rad)
            y1 = CENTER_Y + tick_radius_inner * math.sin(mid_rad)
            x2 = CENTER_X + tick_radius_outer * math.cos(mid_rad)
            y2 = CENTER_Y + tick_radius_outer * math.sin(mid_rad)
            dwg.add(dwg.line(
                start=(x1, y1), end=(x2, y2),
                stroke=INSERTION_COLOR, stroke_width=1.5,
            ))

            # Size label just beyond the tick
            ins_size = site['insertion_size']
            if ins_size >= 1_000_000:
                size_label = f"+{ins_size / 1e6:.1f} Mb"
            elif ins_size >= 1_000:
                size_label = f"+{ins_size / 1e3:.1f} kb"
            else:
                size_label = f"+{ins_size} bp"

            x_lbl = CENTER_X + label_radius * math.cos(mid_rad)
            y_lbl = CENTER_Y + label_radius * math.sin(mid_rad)
            deg = math.degrees(mid_rad)
            rot = deg + 90 if -90 <= deg <= 90 else deg - 90
            dwg.add(dwg.text(
                size_label,
                insert=(x_lbl, y_lbl),
                font_size='9px', text_anchor='middle',
                alignment_baseline='middle',
                fill=INSERTION_COLOR,
                transform=f"rotate({rot:.1f},{x_lbl:.3f},{y_lbl:.3f})",
            ))

    # --- Outermost ring border ---
    if n_queries > 0:
        final_outer_r = (
            BLAST_HIT_BASE_RADIUS
            + (n_queries - 1) * (BLAST_RING_THICKNESS + BLAST_RING_SPACING)
            + BLAST_RING_THICKNESS
        )
        dwg.add(dwg.circle(
            center=(CENTER_X, CENTER_Y), r=final_outer_r,
            fill='none', stroke='#999', stroke_width=1.0,
        ))

    # --- Scale Tick Marks (outside outermost ring) ---
    num_major_ticks = 12
    for i in range(num_major_ticks):
        angle_rad = (i / num_major_ticks) * 2 * math.pi - math.pi / 2
        pos_bp = (i / num_major_ticks) * reference_length

        if reference_length > 2_000_000:
            label = f"{pos_bp / 1e6:.1f} Mb"
        elif reference_length > 2000:
            label = f"{pos_bp / 1e3:.0f} kb"
        else:
            label = f"{int(pos_bp)} bp"

        x1 = CENTER_X + tick_radius_inner * math.cos(angle_rad)
        y1 = CENTER_Y + tick_radius_inner * math.sin(angle_rad)
        x2 = CENTER_X + tick_radius_outer * math.cos(angle_rad)
        y2 = CENTER_Y + tick_radius_outer * math.sin(angle_rad)
        dwg.add(dwg.line(
            start=(x1, y1), end=(x2, y2),
            stroke='#555', stroke_width=1.0,
        ))

        x_text = CENTER_X + label_radius * math.cos(angle_rad)
        y_text = CENTER_Y + label_radius * math.sin(angle_rad)
        dwg.add(dwg.text(
            label, insert=(x_text, y_text),
            text_anchor='middle', alignment_baseline='middle',
            font_size='10px', fill='#555',
        ))

    # =====================================================================
    # --- LEGEND (right side) ---
    # =====================================================================
    legend_x = SVG_WIDTH - 175
    legend_y = 50
    box_size = 14
    item_height = 22

    dwg.add(dwg.text(
        "Legend", insert=(legend_x, legend_y),
        font_weight='bold', font_size='14px', fill='#333',
    ))
    legend_y += item_height + 5

    # --- Query rings ---
    dwg.add(dwg.text(
        "Query Rings", insert=(legend_x, legend_y),
        font_weight='bold', font_size='11px', fill='#555',
    ))
    legend_y += item_height - 2
    for i, name in enumerate(query_names):
        base_r, base_g, base_b = _get_ring_color(i)
        base_color = _rgb_to_hex(base_r, base_g, base_b)
        dwg.add(dwg.rect(
            insert=(legend_x, legend_y),
            size=(box_size, box_size), fill=base_color, rx=2, ry=2,
        ))
        dwg.add(dwg.text(
            name, insert=(legend_x + box_size + 8, legend_y + box_size - 2),
            font_size='10px', fill='#333',
        ))
        legend_y += item_height
    legend_y += 8

    # --- Identity gradient ---
    dwg.add(dwg.text(
        "% Identity", insert=(legend_x, legend_y),
        font_weight='bold', font_size='11px', fill='#555',
    ))
    legend_y += item_height - 2
    gradient_width = 120
    gradient_height = 14
    for i in range(min(n_queries, len(RING_COLORS))):
        grad_id = f"identgrad_query{i}"
        gradient = dwg.linearGradient(start=(0, 0), end=(1, 0), id=grad_id)
        for frac, ident in zip([0, 0.33, 0.66, 1], [70, 80, 90, 100]):
            color = _get_blast_hit_color(i, ident)
            gradient.add_stop_color(offset=frac, color=color)
        dwg.defs.add(gradient)
        dwg.add(dwg.rect(
            insert=(legend_x, legend_y),
            size=(gradient_width, gradient_height),
            fill=f"url(#{grad_id})", rx=2, ry=2,
        ))
        legend_y += gradient_height + 4
    # Percentage labels
    dwg.add(dwg.text(
        "70%", insert=(legend_x, legend_y),
        font_size='9px', fill='#666',
    ))
    dwg.add(dwg.text(
        "100%", insert=(legend_x + gradient_width - 22, legend_y),
        font_size='9px', fill='#666',
    ))
    legend_y += item_height

    # --- Insertion sites legend entry ---
    if insertion_sites:
        dwg.add(dwg.text(
            "Insertions", insert=(legend_x, legend_y),
            font_weight='bold', font_size='11px', fill='#555',
        ))
        legend_y += item_height - 2
        dwg.add(dwg.rect(
            insert=(legend_x, legend_y),
            size=(box_size, box_size), fill='#1a1a1a', rx=2, ry=2,
        ))
        dwg.add(dwg.text(
            "Insertion site",
            insert=(legend_x + box_size + 8, legend_y + box_size - 2),
            font_size='10px', fill='#333',
        ))
        legend_y += item_height + 4

    # --- Annotations legend ---
    if annotations:
        dwg.add(dwg.text(
            "Annotations", insert=(legend_x, legend_y),
            font_weight='bold', font_size='11px', fill='#555',
        ))
        legend_y += item_height - 2
        annotation_types = [
            ("CDS", get_annotation_feature_color("cds")),
            ("Gene", get_annotation_feature_color("gene")),
            ("tRNA", get_annotation_feature_color("trna")),
            ("rRNA", get_annotation_feature_color("rrna")),
        ]
        for label, color in annotation_types:
            dwg.add(dwg.rect(
                insert=(legend_x, legend_y),
                size=(box_size, box_size), fill=color, rx=2, ry=2,
            ))
            dwg.add(dwg.text(
                label,
                insert=(legend_x + box_size + 8, legend_y + box_size - 2),
                font_size='10px', fill='#333',
            ))
            legend_y += item_height

    dwg.save(pretty=True)
